# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['papdl']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'papdl',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Tamim Azmain',
    'author_email': 'maat1@st-andrews.ac.uk',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
